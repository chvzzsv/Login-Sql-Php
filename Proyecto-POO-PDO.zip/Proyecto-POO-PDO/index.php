<?php
session_start();
include_once 'conexion.php';
include_once 'login.php';

$conexion = new ConexionPDO($host, $dbname, $usuario, $contrasena);
$conexion->conectar();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['user'];
    $password = MD5($_POST['pwd']);

    $login = new Login($conexion);


    if ($login->login($usuario, $password)) {
          $_SESSION['usuario']=$usuario;
         header("Location: dash.php");
        exit();
    } else {
         $error_message = "Nombre de usuario o contraseña incorrectos.";
    }
}

$conexion->desconectar();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio Sesión</title>
</head>
    <style>
/* Estilo para el contenedor principal */
body {

  background-image: url(collage-fondo-pelicula.jpg);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 92vh;
  background-color:teal;
  margin: 20px;
}

/* Estilo para el formulario */
form {
  width: 300px;
  padding: 25px;
  border: 3px solid black;
  border-radius: 5px;
  background-color:beige;
}

/* Estilo para el título */
h1 {
  text-align: center;
  margin-bottom: 20px;
  font-size: 24px;
  color: #333;
}

/* Estilo para las etiquetas */
label {
  font-weight: bold;
  color: #333;
}

/* Estilo para los campos de entrada */
input[type="text"],
input[type="password"] {
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

/* Estilo para el botón de enviar */
input[type="submit"] {
  width: 100%;
  padding: 10px;
  background-color: #333;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #555;
}
    </style>
<body>
    <form action="" method="POST">
    <h1>Iniciar Sesión</h1>
    <label for="user">Usuario</label>
    <br>
    <input type="text" name="user" >
    <br>
    <label for="pwd">Contraseña</label>
    <br>
    <input type="password" name="pwd">
    <br>
    <input type="submit" style="background-color: teal" value="Acceder">
    </form>
</body>

</html>
