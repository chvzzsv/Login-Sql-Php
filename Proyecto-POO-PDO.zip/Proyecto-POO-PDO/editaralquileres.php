<?php
session_start();

if($_SESSION['usuario']=== null){
    header('Location:index.php');
}

include_once 'conexion.php';

$conexion = new ConexionPDO($host, $dbname, $usuario, $contrasena);
$conexion->conectar();

$id= $_POST['id'];
$query = "SELECT * FROM cliente";
$statement = $conexion->getConnection()->query($query);
$cliente = $statement->fetchAll(PDO::FETCH_ASSOC);

$query = "SELECT * FROM peliculas";
$statement = $conexion->getConnection()->query($query);
$pelicula = $statement->fetchAll(PDO::FETCH_ASSOC);

$query = "SELECT * FROM alquiler  WHERE id=:id";
$statement = $conexion->getConnection()->prepare($query);
$statement->bindParam(':id', $id);
$statement->execute();
$alquiler = $statement->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  
    <title>Editar</title>
</head>
<style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 92vh;
        background-color:teal;
        margin: 20px;
        }
    /* Estilos para el título */
    title {
        font-size: 24px;
        font-weight: bold;
        color: #333;
    }

    /* Estilos para el formulario */
    form {
        margin: 20px;
    }

    /* Estilos para la etiqueta */
    label {
        font-weight: bold;
        margin-bottom: 10px;
        display: block;
    }

    /* Estilos para el input de texto */
    input[type="text"],
    input[type="date"],
    select {
        width: 800px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        font-size: 14px;
    }

    /* Estilos para el botón */
    input[type="submit"] {
        background-color: #007bff;
        color: #fff;
        padding: 8px 16px;
        border: none;
        border-radius: 3px;
        font-size: 16px;
        cursor: pointer;
    }
</style>

<body>
<form  action="procesos.php" method="POST">
    <input type="text" name="id"  value="<?php echo $alquiler['id'];?>" hidden >
    <label>Fecha estimada</label>
<input class="form-control form-control-sm" style="width:800px;" type="date" name="fecha" value="<?php echo $alquiler['fechaEntrega'];?>">
<br>
    <label>Nombre del cliente</label>
<select class="form-control form-control-sm" style="width:800px;" name="cliente">
<?php
     foreach($cliente as $clientes){
        if($clientes['id']== $alquiler['id_cliente']){
            echo "<option value='".$clientes['id']."' selected>".$clientes['nombre']."</option>";
        }else{
            echo "<option value='".$clientes['id']."' >".$clientes['nombre']."</option>";
        }
       
     }
?>
</select>
<br>
    <label>Películas disponibles</label>
<select class="form-control form-control-sm" style="width:800px;" name="pelicula">
<?php
     foreach($pelicula as $peliculas){
        if($peliculas['id']== $alquiler['id_pelicula']){
            echo "<option value='".$peliculas['id']."' selected>".$peliculas['nombre']."</option>";
        }else{
            echo "<option value='".$peliculas['id']."' >".$peliculas['nombre']."</option>";
        }
        
     }
?>

</select>
<br>
    <label>Precio $</label>
<input class="form-control form-control-sm" placeholder="$" style="width:800px;" type="text" name="costo" value="<?php echo $alquiler['costo'];?>">
<br>
<input type="submit" value="Editar" style="background-color: green" class="btn btn-primary">
<a href='viewalquileres.php' style="background-color: red" class='btn btn-primary'>Cancelar</a>
    </form>
</body>
</html>