<?php
session_start();

if ($_SESSION['usuario'] === null) {
    header('Location:index.php');
}

include_once 'conexion.php';

$conexion = new ConexionPDO($host, $dbname, $usuario, $contrasena);
$conexion->conectar();

$query = "select alquiler.id as id, fechaEntrega, cliente.nombre as cliente, cliente.dui as dui ,peliculas.nombre as pelicula, costo 
FROM alquiler
inner join cliente on alquiler.id_cliente	= cliente.id
inner join peliculas on alquiler.id_pelicula	= peliculas.id";
$statement = $conexion->getConnection()->query($query);
$alquileres = $statement->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Registro de películas</title>

</head>
<style>
    body {
        background-image: url(collage-fondo-pelicula.jpg);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 90vh;
        background-color:teal;
        margin: 20px;
}
    .table {
        width: 100%;
        border-collapse:collapse;
        background-color: seashell;
    }

    .table th,
    .table td {
        border: 3px solid black;
        padding: 15px;
        text-align: center;
    }

    .table th {
        background-color:red;
        font-weight: bold;
    }

    .table tbody tr:nth-child(even) {
        background-color: seashell;
    }
</style>


<body>
    <section style="width:1000px; margin:0 auto;">
        <a href='agregaralquiler.php' style='background-color: green' class='btn btn-primary'>CREAR ✚</a>

        <table class="table">
            <tr>
                <th>ID</th>
                <th>Fecha Estimada</th>
                <th>Cliente</th>
                <th>DUI</th>
                <th>Película</th>
                <th>Precio</th>
                <th>Opción 1</th>
                <th>Opción 2</th>
            </tr>
            <tbody>
                <?php
                foreach ($alquileres as $alquiler) {
                    echo "<tr>";
                    echo "<td>" . $alquiler['id'] . "</td>";
                    echo "<td>" . $alquiler['fechaEntrega'] . "</td>";
                    echo "<td>" . $alquiler['cliente'] . "</td>";
                    echo "<td>" . $alquiler['dui'] . "</td>";
                    echo "<td>" . $alquiler['pelicula'] . "</td>";
                    echo "<td>" . $alquiler['costo'] . "</td>";
                    echo "<td><form action='editaralquileres.php' method='POST'>
                <input type='text' name='id' value='" . $alquiler['id'] . "' hidden >
               <input type='submit' class='btn btn-success' style='background-color: green' value='ACTUALIZAR ⇄'>
               </form></td>";

                    echo "<td><form action='eliminaralquiler.php' method='POST'>
                        <input type='text' name='id' value='" . $alquiler['id'] . "' hidden >
                       <input type='submit' class='btn btn-danger' style='background-color: red' value='BORRAR 🗑️'>
                       </form></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

    </section>
</body>

</html>